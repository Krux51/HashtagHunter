package com.example.sampleapp.models.unsplash;

public class UnsplashPhoto {
    public UnsplashUrls getUrls() {
        return urls;
    }

    public void setUrls(UnsplashUrls urls) {
        this.urls = urls;
    }

    private UnsplashUrls urls;
}
