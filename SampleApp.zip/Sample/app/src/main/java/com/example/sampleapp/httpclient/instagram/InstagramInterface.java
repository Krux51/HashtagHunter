package com.example.sampleapp.httpclient.instagram;

import com.example.sampleapp.models.instagram.InstagramUserMediaResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface InstagramInterface {
    @GET("me/media")
    Call<InstagramUserMediaResponse> getInstagramUserMedia(@Query("fields") String fields, @Query("limit") String limit, @Query("access_token") String access_token);
}
