package com.example.sampleapp;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.sampleapp.httpclient.instagram.InstagramClient;
import com.example.sampleapp.models.instagram.InstagramUserMediaResponse;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;

public class InstagramActivity extends AppCompatActivity {
    private ImageView imageIv;
    private TextView captionTv;
    private Button searchBtn;
    private InstagramClient instagramClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instagram);
        imageIv = findViewById(R.id.instagramIv);
        captionTv = findViewById(R.id.captionTv);
        searchBtn = findViewById(R.id.instagramSearchBtn);
        instagramClient = new InstagramClient();

        instagramClient.getInstagramMedia(
                new InstagramClient.OnLoadMediaListener() {
                    @Override
                    public void onResponse(Call<InstagramUserMediaResponse> call, Response<InstagramUserMediaResponse> response) {
                        int statusCode = response.code();
                        if (statusCode == 200) {
                            Glide
                                    .with(InstagramActivity.this)
                                    .load(Uri.parse(response.body().getData()[0].getMedia_url()))
                                    .into(imageIv);

                            captionTv.setText(response.body().getData()[0].getCaption());
                            Log.i("Instagram", response.body().getData()[0].getCaption());
                        } else if (statusCode >= 400) {
                            Toast.makeText(InstagramActivity.this, String.valueOf(statusCode), Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<InstagramUserMediaResponse> call, Throwable t) {
                        captionTv.setText("Error "+ t.getMessage());
                        t.printStackTrace();
                    }
                });

        searchBtn.setOnClickListener(v -> {
            ArrayList<InstagramUserMediaResponse.MediaData> filteredPosts = instagramClient.doSearch("ganesha");
            captionTv.setText(filteredPosts.get(0).getCaption());
            Glide
                    .with(InstagramActivity.this)
                    .load(Uri.parse(filteredPosts.get(0).getMedia_url()))
                    .into(imageIv);
        });
    }
}
