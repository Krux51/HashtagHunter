package com.example.sampleapp.models.facebook;

import java.util.ArrayList;

public class FacebookPostsResponse {

    public PostData[] getData() { return data; }

    public void setData(PostData[] data) { this.data = data; }

    private PostData[] data;

    public class PostData {

        public String getCreated_time() { return created_time; }

        public void setCreated_time(String created_time) { this.created_time = created_time; }

        public String getMessage() { return message; }

        public void setMessage(String message) { this.message = message; }

        public String getId() { return id; }

        public void setId(String id) { this.id = id; }

        public String getPicture() { return picture; }

        public void setPicture(String picture) { this.picture = picture; }

        public void createHashtags() {
            this.message.replaceAll("\r", "\n");
            String[] allWords = this.message.split(" ");
            this.hashtags = new ArrayList<>();
            for (int i = 0; i < allWords.length; i++) {
                if (allWords[i].length() > 1 && allWords[i].indexOf("#") == 0) {
                    String tag = "";
                    if (allWords[i].indexOf("\n") > 0 && allWords[i].substring(1, allWords[i].indexOf("\n")).length() > 1)
                        tag = allWords[i].substring(1, allWords[i].indexOf("\n"));
                    else if (allWords[i].indexOf("\n") <= 0)
                        tag = allWords[i].substring(1);

                    if (!tag.isEmpty() && !this.hashtags.contains(tag))
                        this.hashtags.add(tag);
                }
            }
        }

        public ArrayList<String> getHashtags() { return hashtags; }

        private String created_time;
        private String message;
        private String id;
        private String picture;
        private ArrayList<String> hashtags;
    }
}
