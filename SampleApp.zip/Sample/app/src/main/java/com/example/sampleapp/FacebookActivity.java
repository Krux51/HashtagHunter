package com.example.sampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.sampleapp.httpclient.facebook.FacebookClient;
import com.example.sampleapp.models.facebook.FacebookPostsResponse;
import com.example.sampleapp.models.facebook.LongLivedTokenResponse;
import com.example.sampleapp.models.facebook.ShortLivedTokenResponse;
import com.example.sampleapp.models.instagram.InstagramUserMediaResponse;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;

public class FacebookActivity extends AppCompatActivity {

    private TextView message;
    private Button searchBtn;
    private ImageView fbPostIv;
    private FacebookClient facebookClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facebook);
        message = findViewById(R.id.messageTv);
        searchBtn = findViewById(R.id.facebookSearchBtn);
        fbPostIv = findViewById(R.id.facebookPostImg);
        facebookClient = new FacebookClient();
        facebookClient.getShortLivedToken(
            new FacebookClient.OnShortLivedTokenListener() {
                @Override
                public void onResponse(Call<ShortLivedTokenResponse> call, Response<ShortLivedTokenResponse> response) {
                    ShortLivedTokenResponse shortLivedToken = response.body();
                    Log.i("Facebook", shortLivedToken.getData()[0].getAccess_token());

                    facebookClient.getLongLivedToken(new FacebookClient.OnLongLivedTokenListener() {

                        @Override
                        public void onResponse(Call<LongLivedTokenResponse> call, Response<LongLivedTokenResponse> response) {
                            LongLivedTokenResponse longLivedToken = response.body();
                            Log.i("Facebook", longLivedToken.getAccess_token());

                            facebookClient.getFacebookPosts(
                                    new FacebookClient.OnLoadPostsListener() {
                                        @Override
                                        public void onResponse(Call<FacebookPostsResponse> call, Response<FacebookPostsResponse> response) {
                                            message.setText(response.body().getData()[0].getMessage());
                                            Log.i("facebook", response.body().getData()[0].getPicture());
                                            Glide
                                                    .with(FacebookActivity.this)
                                                    .load(Uri.parse(response.body().getData()[0].getPicture()))
                                                    .into(fbPostIv);
                                        }

                                        @Override
                                        public void onFailure(Call<FacebookPostsResponse> call, Throwable t) {
                                            Toast.makeText(FacebookActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                                            t.printStackTrace();
                                        }
                                    }
                            );
                        }

                        @Override
                        public void onFailure(Call<LongLivedTokenResponse> call, Throwable t) {
                            Toast.makeText(FacebookActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                            t.printStackTrace();
                        }
                    }, shortLivedToken.getData()[0].getAccess_token());
                }

                @Override
                public void onFailure(Call<ShortLivedTokenResponse> call, Throwable t) {
                    Toast.makeText(FacebookActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                    t.printStackTrace();
                }
            });

        searchBtn.setOnClickListener(v -> {
            ArrayList<FacebookPostsResponse.PostData> filteredPosts = facebookClient.doSearch("SwachhBharat");
            Log.i("Facebook", filteredPosts.size() + "");
            message.setText(filteredPosts.get(0).getMessage());
            Glide
                    .with(FacebookActivity.this)
                    .load(Uri.parse(filteredPosts.get(0).getPicture()))
                    .into(fbPostIv);
        });
    }
}