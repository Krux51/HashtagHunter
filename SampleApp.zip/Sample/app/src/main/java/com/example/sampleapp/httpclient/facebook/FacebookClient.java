package com.example.sampleapp.httpclient.facebook;

import com.example.sampleapp.models.facebook.FacebookPostsResponse;
import com.example.sampleapp.models.facebook.LongLivedTokenResponse;
import com.example.sampleapp.models.facebook.ShortLivedTokenResponse;

import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FacebookClient {

    private static final String BASE_URL = "https://graph.facebook.com/";

    private String appId = "404465713297212";
    private String appSecret = "8373330997174e2236dadbd42df649f7";
    private String appAccessToken = "404465713297212|cvktOE7s02vRGU0BK1Z0eCCFpdQ";

    private HashMap<String, ArrayList<FacebookPostsResponse.PostData>> filteredPosts = new HashMap<>();    // key = hashtag, value = arraylist of posts

    private final FacebookInterface facebookApi;

    public FacebookClient() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        facebookApi = retrofit.create(FacebookInterface.class);
    }

    public interface OnShortLivedTokenListener extends Callback<ShortLivedTokenResponse> {}
    public interface OnLongLivedTokenListener extends Callback<LongLivedTokenResponse> {}
    public interface OnLoadPostsListener extends Callback<FacebookPostsResponse> {}
    private interface OnProcessPostsListener extends Callback<FacebookPostsResponse> {}

    private void processPosts(FacebookPostsResponse.PostData[] data) {
        for (int i = 0; i < data.length; i++) {
            data[i].createHashtags();
            for (String hashtag : data[i].getHashtags()) {
                if (filteredPosts.get(hashtag) == null) {
                    ArrayList<FacebookPostsResponse.PostData> posts = new ArrayList<>();
                    posts.add(data[i]);
                    filteredPosts.put(hashtag, posts);
                } else {
                    filteredPosts.get(hashtag).add(data[i]);
                }
            }
        }
    }

    public void getShortLivedToken (OnShortLivedTokenListener listener) {
        facebookApi.getShortLivedToken(appAccessToken).enqueue(listener);
    }

    public void getLongLivedToken (OnLongLivedTokenListener listener, String shortLivedToken) {
        facebookApi.getLongLivedToken(appId, appSecret, shortLivedToken).enqueue(listener);
    }

    public void getFacebookPosts (OnLoadPostsListener listener) {
        String rutu_access_token = "751420229119154|c-uzzb0JZTly6l8w_G52n4SOzIM";
        String fields = "created_time,from,link,message,picture,type,attachments";
        facebookApi.getFacebookPosts(rutu_access_token, fields).enqueue(new OnProcessPostsListener() {
            @Override
            public void onResponse(Call<FacebookPostsResponse> call, Response<FacebookPostsResponse> response) {
                processPosts(response.body().getData());
                listener.onResponse(call, response);
            }

            @Override
            public void onFailure(Call<FacebookPostsResponse> call, Throwable t) {
                listener.onFailure(call, t);
            }
        });
    }

    public ArrayList<FacebookPostsResponse.PostData> doSearch (String query) {
        return filteredPosts.get(query);
    }
}