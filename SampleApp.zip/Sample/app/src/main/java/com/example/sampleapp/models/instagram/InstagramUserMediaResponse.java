package com.example.sampleapp.models.instagram;

import java.util.ArrayList;

public class InstagramUserMediaResponse {

    public void setData (MediaData[] data) { this.data = data; }

    public MediaData[] getData() { return this.data; }

    private MediaData[] data;

    public class MediaData {
        public void setId (String id) { this.id = id; }

        public String getId() { return this.id; }

        public void setCaption (String caption) { this.caption = caption; }

        public String getCaption() { return this.caption; }

        public void setMedia_url(String url) { this.media_url = url; }

        public String getMedia_url() { return this.media_url; }

        public void setTimestamp (String timestamp) { this.timestamp = timestamp; }

        public String getTimestamp() { return this.timestamp; }

        public void createHashtags() {
            this.caption.replaceAll("\r", "\n");
            String[] allWords = this.caption.split(" ");
            this.hashtags = new ArrayList<>();
            for (int i = 0; i < allWords.length; i++) {
                if (allWords[i].length() > 1 && allWords[i].indexOf("#") == 0) {
                    String tag = "";
                    if (allWords[i].indexOf("\n") > 0 && allWords[i].substring(1, allWords[i].indexOf("\n")).length() > 1)
                        tag = allWords[i].substring(1, allWords[i].indexOf("\n"));
                    else if (allWords[i].indexOf("\n") <= 0)
                        tag = allWords[i].substring(1);

                    if (!tag.isEmpty() && !this.hashtags.contains(tag))
                        this.hashtags.add(tag);
                }
            }
        }

        public ArrayList<String> getHashtags() { return hashtags; }

        private String id, caption, media_url, timestamp;
        private ArrayList<String> hashtags;
    }
}
