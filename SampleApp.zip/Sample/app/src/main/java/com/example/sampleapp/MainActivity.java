package com.example.sampleapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.sampleapp.httpclient.unsplash.UnsplashClient;
import com.example.sampleapp.models.unsplash.UnsplashPhoto;

import retrofit2.Call;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private UnsplashClient unsplash;
    private ImageView imageView;
    private Button fbButton;
    private Button instagramButton;

    //IGQVJXenN3dks4T1hNaEp2WGl0MmpXc2MtSGtBSndMbmlpTkpBRUJJcVdjSElxRnZASQTJ0X2dsLWN6WlBRaDZAFMVIwNFdnS2ZAYM0RMVW5jNmRqdUhOdU5jMTl0bzExWDJ6bVQ4RlNCSTgwN3NhSTg2QwZDZD

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageIv);
        fbButton = findViewById(R.id.facebookScreenBtn);
        instagramButton = findViewById(R.id.instagramScreenBtn);
        unsplash = new UnsplashClient();
        unsplash.getRandomPhoto(
                new UnsplashClient.OnPhotoLoadedListener() {
                    @Override
                    public void onResponse(Call<UnsplashPhoto> call, Response<UnsplashPhoto> response) {
                        int statusCode = response.code();
                        if (statusCode == 200) {
                            Glide
                                    .with(MainActivity.this)
                                    .load(Uri.parse(response.body().getUrls().getRegular()))
                                    .into(imageView);
                        } else if (statusCode >= 400) {
                            Toast.makeText(MainActivity.this, String.valueOf(statusCode), Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<UnsplashPhoto> call, Throwable t) {
                        Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
        );
        fbButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FacebookActivity.class);
            startActivity(intent);
        });
        instagramButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InstagramActivity.class);
            startActivity(intent);
        });
    }
}