package com.example.sampleapp.httpclient.facebook;

import com.example.sampleapp.models.facebook.FacebookPostsResponse;
import com.example.sampleapp.models.facebook.LongLivedTokenResponse;
import com.example.sampleapp.models.facebook.ShortLivedTokenResponse;
import com.example.sampleapp.models.unsplash.UnsplashPhoto;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface FacebookInterface {
    @GET("404465713297212/accounts")
    Call<ShortLivedTokenResponse> getShortLivedToken(@Query("access_token") String appAccessToken);

    @GET("oauth/access_token?grant_type=fb_exchange_token")
    Call<LongLivedTokenResponse> getLongLivedToken(@Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("fb_exchange_token") String fbShortLivedToken);

    @GET("108381664623944/feed")
    Call<FacebookPostsResponse> getFacebookPosts(@Query("access_token") String access_token, @Query("fields") String fields);
}
