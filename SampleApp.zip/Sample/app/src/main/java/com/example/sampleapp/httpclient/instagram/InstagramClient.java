package com.example.sampleapp.httpclient.instagram;

import android.util.Log;

import com.example.sampleapp.models.instagram.InstagramUserMediaResponse;

import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class InstagramClient {

    private static final String BASE_URL = "https://graph.instagram.com";

    private String access_token = "IGQVJXenN3dks4T1hNaEp2WGl0MmpXc2MtSGtBSndMbmlpTkpBRUJJcVdjSElxRnZASQTJ0X2dsLWN6WlBRaDZAFMVIwNFdnS2ZAYM0RMVW5jNmRqdUhOdU5jMTl0bzExWDJ6bVQ4RlNCSTgwN3NhSTg2QwZDZD";
    private HashMap<String, ArrayList<InstagramUserMediaResponse.MediaData>> filteredMedia = new HashMap<>();    // key = hashtag, value = arraylist of posts

    private final InstagramInterface instagramApi;

    public InstagramClient() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        instagramApi = retrofit.create(InstagramInterface.class);
    }

    public interface OnLoadMediaListener extends Callback<InstagramUserMediaResponse> {}
    private interface OnProcessMediaListener extends Callback<InstagramUserMediaResponse> {}

    private void processMedia (InstagramUserMediaResponse.MediaData[] data) {
        for (int i = 0; i < data.length; i++) {
            data[i].createHashtags();
            for (String hashtag : data[i].getHashtags()) {
                if (filteredMedia.get(hashtag) == null) {
                    ArrayList<InstagramUserMediaResponse.MediaData> posts = new ArrayList<>();
                    posts.add(data[i]);
                    filteredMedia.put(hashtag, posts);
                } else {
                    filteredMedia.get(hashtag).add(data[i]);
                }
            }
        }
    }

    public void getInstagramMedia (OnLoadMediaListener listener) {
        String fields = "id,caption,media_url,timestamp";
        instagramApi.getInstagramUserMedia(fields, "500", access_token).enqueue(new OnProcessMediaListener() {
            @Override
            public void onResponse(Call<InstagramUserMediaResponse> call, Response<InstagramUserMediaResponse> response) {
                processMedia(response.body().getData());
                listener.onResponse(call, response);
            }

            @Override
            public void onFailure(Call<InstagramUserMediaResponse> call, Throwable t) {
                listener.onFailure(call, t);
            }
        });
    }

    public ArrayList<InstagramUserMediaResponse.MediaData> doSearch (String query) {
        return filteredMedia.get(query);
    }
}
