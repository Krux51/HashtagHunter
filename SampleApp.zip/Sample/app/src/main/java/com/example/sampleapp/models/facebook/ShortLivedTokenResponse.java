package com.example.sampleapp.models.facebook;

public class ShortLivedTokenResponse {
    private TokenData[] data;

    public void setData (TokenData[] data) {
        this.data = data;
    }

    public TokenData[] getData() {
        return this.data;
    }

    public class TokenData {
        public String getAccess_token() {
            return access_token;
        }

        public void setAccess_token(String access_token) {
            this.access_token = access_token;
        }

        private String access_token;
    }
}
